let value = 0;
var Xmenu1 = 150;
var Xmenu = 10;
var Xbotao2 = 260;
var Ymenu1=260, Ymenu2 = 340, Ymenu3 = 420, Ymenu4 = 500, Ymenu5 = 180;
var largura = 230;
var altura = 55;
var XminBotao = Xmenu, XminBotao1 = Xmenu1, XmaxBotao = XminBotao + largura, XmaxBotao1 = XminBotao1 + largura;
var YmaxBotao1 = Ymenu1 + altura, YmaxBotao2 = Ymenu2 + altura, YmaxBotao3 = Ymenu3 + altura, YmaxBotao4 = Ymenu4 + altura, YmaxBotao5 = Ymenu5 + altura;
var largura2 = 90, altura2 = 45;
var XminF2_1 = 15, XmaxF2_1 = XminF2_1+largura2, XminF2_2 = 140, XmaxF2_2 = XminF2_2 +largura2, XminF2_3 = 260, XmaxF2_3 = XminF2_3+largura2, XminF2_4 = 380, XmaxF2_4 = XminF2_4+largura2;
var Yfase = 170, YmaxFase = Yfase + altura2;
var largura3 = 100;
var XminF3_1 = 15, XmaxF3_1 = XminF3_1+largura3, XminF3_2 = 140, XmaxF3_2 = XminF3_2 +largura3, XminF3_3 = 260, XmaxF3_3 = XminF3_3+largura3, XminF3_4 = 380, XmaxF3_4 = XminF3_4+largura3;
var Yfase4 = 300, YmaxFase4 = Yfase4 + altura2;
var largura5 = 240;
var XminF5 = 15, XmaxF5 = XminF5+largura5;
var Yfase5_1 = 110, YmaxFase5_1 = Yfase5_1 + altura2; Yfase5_2 = 170; 
var YmaxFase5_2 = Yfase5_2 + altura2, Yfase5_3 = 230, YmaxFase5_3 = Yfase5_3+altura2;
var Yfase6 = 300, YmaxFase6 = Yfase6 + altura2;
var XminF5_1 = 5, XmaxF5_1 = XminF5_2+largura5,XminF5_2 = 257, XmaxF5_2 = XminF5_2+largura5, XminF5_3 = 135, XmaxF5_3 = XminF5_3+largura5;
var XminF11_1 = 120, XmaxF11_1 = XminF11_1+largura2;
var Xmin11_2 = 280, Xmax11_2 = Xmin11_2+largura2;
var Yfase11 = 300, YmaxFase11 = Yfase11 + altura2;


var tela = 1
/* tela 0 = 0
menu = 1
instruções = 2
dicas = 3
temp = 4
massa = 5
tempo = 6
comp. = 7
corrente = 8
quant. massa = 9
int.luminosa = 10
fase 0 = 11
fase 1 = 12
fase 2 = 14
fase 3 = 15
fase 4 = 16
fase 5 = 17
fase 6 = 18
fase 7 = 19
fase 8 = 20
fase 9 = 21
fase 10 = 22
fase 11 = 23
game over = 24
creditostela = 25
*/

function tela30(){
  background(255);
   let g = color(150);
   image(img11, 10,20, 500, 600);
  textFont(font1);
  textSize(20);
  fill(g);
  text('Olá, seja bem vindo ao jogo Salvador da Matemática. Eu sou o Salvador Dali   moderno e vim ajudar você a utilizar o Sistema Internacional de Unidades!', 92,100, 250);
  
  if( mouseX > 380 && mouseX < 460 && mouseY > 555 && mouseY < 567){
     noStroke();
  fill(2000)
  rect(380, 555, 80, 17);
    if(mouseIsPressed){
      value = 11;
      tela = 1
    } 
  }
  noStroke();
  fill(2000)
  rect(380, 555, 80, 17);
}
function telaMenu(){
  background(255, 249, 229);
  let u = color(0);
  let x = color(242, 204, 255);
  let z = color(179, 217, 255);
  let l = color(179, 179, 255);
  let g = color(255, 204, 204);
  let j = color(230);
  let s = color(255, 249, 229);
  textFont(fonte3);
  textSize(70);
  stroke(50);
  fill(u);
  text('Salvador', 150,80);
  textFont(fonte1);
  textSize(40);
  
  fill(u);
  text('da', 225, 150);
  textFont(fonte4);
  textSize(50)
  fill(g)
  text('Matemática', 10,200)

 
  if( mouseX > XminBotao1 && mouseX < XmaxBotao1 && mouseY > Ymenu1 && mouseY < YmaxBotao1){
    fill(s);
    if(mouseIsPressed){
      value = 9
      tela = 11
    } 
  }
  rect(Xmenu1, Ymenu1, largura, altura, 15);
  textFont(font2);
  textSize(40);
  fill(u)
  text('Jogar', Xmenu1 + 60, 300);
  
  if( mouseX > XminBotao1 && mouseX < XmaxBotao1 && mouseY > Ymenu2 && mouseY < YmaxBotao2){ 
    fill(s);
   rect(Xmenu1, Ymenu2, largura, altura, 15);
     if(mouseIsPressed){
       value = 12
      tela = 2;
     } 
  }else{
    fill(x);
    rect(Xmenu1, Ymenu2, largura, altura, 15);
  } 
  fill(u)
  text('Instruções', Xmenu1 + 30, 380); 
  
  if( mouseX > XminBotao1 && mouseX < XmaxBotao1 && mouseY > Ymenu3 && mouseY < YmaxBotao3){ 
    fill(s);
   rect(Xmenu1, Ymenu3, largura, altura, 15);
     if(mouseIsPressed){
      value = 1;
      tela = 3
     } 
  }else{
    fill(z);
    rect(Xmenu1, Ymenu3, largura, altura, 15);
  } 
  fill(u)
  text('Dicas', Xmenu1 + 70, 460);
  
  if( mouseX > XminBotao1 && mouseX < XmaxBotao1 && mouseY > Ymenu4 && mouseY < YmaxBotao4){ 
    fill(s);
   rect(Xmenu1, Ymenu4, largura, altura, 15);
     if(mouseIsPressed){
       value = 25
      tela = 25;
     } 
  }else{
    fill(l);
    rect(Xmenu1, Ymenu4, largura, altura, 15);
  } 
     
  fill(u)
  text('Créditos', Xmenu1 + 50, 540);
}
function telaFase0(){
  background(img3);
   let h = color(255, 204, 153);
   let g = color(255, 153, 153);
  let y = color(255, 255, 230);
  let x = color(255, 255, 204);
  
  fill(0);
  textFont(font1);
  textSize(40);
  text('Não se esqueça, use as dicas!', 30, 70,300);
   noStroke();
  
  if( mouseX > 100 && mouseX < 285 && mouseY > 180 && mouseY < 235){ 
    fill(x);
     rect(100,180,185,55,5);
     if(mouseIsPressed){
      value = 120;
       tela = 12;
     } 
  }else{
  fill(h);
  rect(100,180,185,55,5);
  } 
  fill(0);
  text('Começar', 120, 220);
   fill(h);
  noStroke();
  ellipse(480, 0, 150, 150);
}
 function telaFase1(){
   background(2000);
    //organização das cores
  let z = color(255, 204, 153);
  let a = color(255, 249, 229);
  let u = color(0);
   textFont(font1);
   textSize(30);
   fill(u); 
   text('Quais são as 7 unidades do Sistema Internacional de Unidades?',10,80,480);
   
   if( mouseX > 15 && mouseX < 475 && mouseY > 165 && mouseY < 230){ 
     noStroke();
     fill(a);
     rect(15, 165, 460, 65, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(z);
    noStroke();
    rect(15, 165, 460, 65, 5);
  } 
  textSize(20);
  fill(20)
  text('      Horas,    Quilograma,    Mol,    Condela,    Centímetro,     Ampère     e     Celsius', 20, 190,450);
   
   if( mouseX > 15 && mouseX < 475 && mouseY > 265 && mouseY < 330){ 
    fill(a);
    rect(15, 265, 460, 65, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(z);
    noStroke();
    rect(15, 265, 460, 65, 5);
  } 
  fill(20);
  text('   Segundo,    Miligrama,    Mol,    Condela,     Metro,    Hertz    e    Farenrich', 20, 290,450);
   
   if( mouseX > 15 && mouseX < 475 && mouseY > 370 && mouseY < 435){ 
     fill(a);
   rect(15, 370, 460, 65, 5);
     if(mouseIsPressed){
       value = 13;
       tela = 14;
     } 
  }else{
    fill(z);
    noStroke();
    rect(15, 370, 460, 65, 5);
  } 
   fill(20);
  text('  Segundo,    Quilograma,    Mol,    Candela,    Metro,   Ampère   e   Kelvin', 20, 395,450);
} 
function telaFase2(){
  background(img13);
   //organização das cores
  let a = color(255, 249, 229);
  let f = color(255, 204, 255);
  let u = color(0);
  fill(u);
  textFont(font1);
  textSize(30);
  text('Qual é a temperatura de 25°C,  em Kelvin?', 15,80, 480)
  
   if( mouseX > XminF2_1 && mouseX < XmaxF2_1 && mouseY >Yfase  && mouseY < YmaxFase){ 
     noStroke();
     fill(a);
   rect(XminF2_1, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 14;
       tela = 15;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_1, Yfase, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('298,15 K', XminF2_1+5, Yfase+30);
   
   if( mouseX > XminF2_2 && mouseX < XmaxF2_2 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_2, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_2, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('298,15°K', XminF2_2+5, Yfase+30);
   if( mouseX > XminF2_3 && mouseX < XmaxF2_3 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_3, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_3, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('288,23 K', XminF2_3+5, Yfase+30);
  
   if( mouseX > XminF2_4 && mouseX < XmaxF2_4 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_4, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_4, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('288,23°K ', XminF2_4+5, Yfase+30); 
}
function telaFase3(){
   //organização das cores
  let a = color(255, 249, 229);
  let f = color(204, 217, 255);
  let u = color(0);
  background(2000);
  image(img14, 0, 20, 800,800)
  textFont(font1);
  textSize(30);
  text('Se um dia possui 24 horas, quantos segundos há em um dia?', 15,80, 480)
 
  if( mouseX > XminF3_1 && mouseX < XmaxF3_1 && mouseY >Yfase  && mouseY < YmaxFase){ 
     noStroke();
     fill(a);
   rect(XminF3_1, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_1, Yfase, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('90.000s', XminF3_1+10, Yfase+30);
   
   if( mouseX > XminF3_2 && mouseX < XmaxF3_2 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF3_2, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_2, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('86.000s', XminF2_2+10, Yfase+30);
   if( mouseX > XminF3_3 && mouseX < XmaxF3_3 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF3_3, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_3, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('87.500s', XminF3_3+10, Yfase+30);
  
   if( mouseX > XminF3_4 && mouseX < XmaxF3_4 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF3_4, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 15;
       tela = 16;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_4, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('86.400s', XminF3_4+10, Yfase+30); 
}
function telaFase4(){
  background(2000);
   //organização das cores
  let a = color(255, 249, 229);
  let f = color(255, 217, 204);
  let u = color(0);
  textFont(font1);
  textSize(30);
  text('Salvador   precisa   comprar   7800   gramas   de   banana   e   800.000   miligramas  de  morango.  Quantos  quilogramas  Salvador  irá comprar   de   ambas   as   frutas?', 15,80, 480)
   if( mouseX > XminF3_1 && mouseX < XmaxF3_1 && mouseY >Yfase4  && mouseY < YmaxFase4){ 
     noStroke();
     fill(a);
   rect(XminF3_1, Yfase4, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_1, Yfase4, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('9,2 kg', XminF3_1+20, Yfase4+30);
   
   if( mouseX > XminF3_2 && mouseX < XmaxF3_2 && mouseY > Yfase4 && mouseY < YmaxFase4){ 
    fill(a);
   rect(XminF3_2, Yfase4, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 16;
       tela = 17;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_2, Yfase4, largura2, altura2, 5);
  } 
  fill(20);
  text('8,6 kg', XminF2_2+20, Yfase4+30);
   if( mouseX > XminF3_3 && mouseX < XmaxF3_3 && mouseY > Yfase4 && mouseY < YmaxFase4){ 
    fill(a);
   rect(XminF3_3, Yfase4, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_3, Yfase4, largura2, altura2, 5);
  } 
  fill(20);
  text('7,6 kg', XminF3_3+20, Yfase4+30);
  
   if( mouseX > XminF3_4 && mouseX < XmaxF3_4 && mouseY > Yfase4 && mouseY < YmaxFase4){ 
    fill(a);
   rect(XminF3_4, Yfase4, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF3_4, Yfase4, largura2, altura2, 5);
  } 
  fill(20);
  text('8,8 kg', XminF3_4+20, Yfase4+30); 
}
function telaFase5(){
   //organização das cores
  let a = color(255, 249, 229);
  let f = color(255, 255, 204);
  let u = color(0);
  background(2000);
  image(img16, 80, 110, 400,500)
  textFont(font1);
  textSize(30);
  fill(u);
  text('Candela é a unidade que mede:', 15,60, 480)
  if( mouseX > XminF5 && mouseX < XmaxF5 && mouseY >Yfase5_1  && mouseY < YmaxFase5_1){ 
     noStroke();
     fill(a);
   rect(XminF5, Yfase5_1, largura5, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5, Yfase5_1, largura5, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('       Iluminância', XminF5+20, Yfase5_1+30);
   
   if( mouseX > XminF5 && mouseX < XmaxF5 && mouseY > Yfase5_2 && mouseY < YmaxFase5_2){ 
    fill(a);
   rect(XminF5, Yfase5_2, largura5, altura2, 5);
     if(mouseIsPressed){
       value = 23;
      tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5, Yfase5_2, largura5, altura2, 5);
  } 
  fill(20);
  text('     Fluxo luminoso', XminF5+20, Yfase5_2+30);
   if( mouseX > XminF5 && mouseX < XmaxF5 && mouseY > Yfase5_3 && mouseY < YmaxFase5_3){ 
    fill(a);
   rect(XminF5, Yfase5_3, largura5, altura2, 5);
     if(mouseIsPressed){
       value = 17;
       tela = 18;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5, Yfase5_3, largura5, altura2, 5);
  } 
  fill(20);
  text('Intensidade luminosa', XminF5+20, Yfase5_3+30);
  }
function telaFase6(){
  background(2000);
     //organização das cores
  let a = color(255, 249, 229);
  let f = color(255, 179, 217);
  let u = color(0);
  textFont(font1);
  textSize(25);
  text('Salvador  decide  ir  ao   jogo  de  futebol  do  seu  time   favorito,  mas quando chega ao  estádio  fica  curioso  com  o  perímetro  total  do  campo.  Sabe-se  que  o  campo   tem  0,11  quilômetros  de  comprimento  e  0,075 quilômetros  de largura, qual o valor  do  perímetro  total  em  metros?', 10,60, 485)

  
   if( mouseX > XminF2_1 && mouseX < XmaxF2_1 && mouseY >Yfase6  && mouseY < YmaxFase6){ 
     noStroke();
     fill(a);
   rect(XminF2_1, Yfase6, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 18;
       tela = 19;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_1, Yfase6, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('370 m', XminF2_1+20, Yfase6+30);
   
   if( mouseX > XminF2_2 && mouseX < XmaxF2_2 && mouseY > Yfase6 && mouseY < YmaxFase6){ 
    fill(a);
   rect(XminF2_2, Yfase6, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_2, Yfase6, largura2, altura2, 5);
  } 
  fill(20);
  text('320 m', XminF2_2+20, Yfase6+30);
   if( mouseX > XminF2_3 && mouseX < XmaxF2_3 && mouseY > Yfase6 && mouseY < YmaxFase6){ 
    fill(a);
   rect(XminF2_3, Yfase6, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_3, Yfase6, largura2, altura2, 5);
  } 
  fill(20);
  text('480 m', XminF2_3+20, Yfase6+30);
  
   if( mouseX > XminF2_4 && mouseX < XmaxF2_4 && mouseY > Yfase6 && mouseY < YmaxFase6){ 
    fill(a);
   rect(XminF2_4, Yfase6, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_4, Yfase6, largura2, altura2, 5);
  } 
  fill(20);
  text('450 m', XminF2_4+20, Yfase6+30);
}
function telaFase7(){
  background(2000);
  //organização das cores
  let a = color(255, 249, 229);
  let f = color(230, 255, 204);
  let u = color(0);
  
  image(img20, 100, 200, 300,400)
  textFont(font1);
  textSize(30);
  text('Determine a quantidade de matéria presente em um mol:', 15,30, 480);
  
  if( mouseX > XminF5_1 && mouseX < XmaxF5_1 && mouseY > Yfase5_1 && mouseY < YmaxFase5_1){ 
    fill(a);
   rect(XminF5_1, Yfase5_1, largura5, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5_1, Yfase5_1, largura5, altura2, 5);
  } 
  textSize(20);
  fill(20);
  text('6,02314076 X 10^24', XminF5_1+30, Yfase5_1+30);
  
   if( mouseX > XminF5_2 && mouseX < XmaxF5_2 && mouseY > Yfase5_1 && mouseY < YmaxFase5_1){ 
    fill(a);
   rect(XminF5_2, Yfase5_1, largura5, altura2, 5);
     if(mouseIsPressed){
       value = 18; 
       tela = 19;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5_2, Yfase5_1, largura5, altura2, 5);
  } 
  fill(20);
  text('6.02214076 X 10^23', XminF5_2+30, Yfase5_1+30);
  
   if( mouseX > XminF5_3 && mouseX < XmaxF5_3 && mouseY > Yfase5_2 && mouseY < YmaxFase5_3){ 
    fill(a);
   rect(XminF5_3, Yfase5_2, largura5, altura2, 5);
     if(mouseIsPressed){
        value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF5_3, Yfase5_2, largura5, altura2, 5);
  } 
  fill(20);
  text('6,02931407 X 10^26', XminF5_3+30, Yfase5_2+30);
}
function telaFase8(){
  background(2000);
  //organização das cores
  let a = color(255, 249, 229);
  let f = color(255, 204, 204);
  let u = color(0);
  image(img19, 100, 120, 400,500)
  textFont(font1);
  textSize(30);
  text('Um movimento ordenado de vetores é medido por:', 15,70, 480);
  
   if( mouseX > XminF2_1 && mouseX < XmaxF2_1 && mouseY >Yfase  && mouseY < YmaxFase){ 
     noStroke();
     fill(a);
   rect(XminF2_1, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 19;
       tela = 21;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_1, Yfase, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('Ampère', XminF2_1+15, Yfase+30);
   
   if( mouseX > XminF2_2 && mouseX < XmaxF2_2 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_2, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_2, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('Volts', XminF2_2+20, Yfase+30);
  
   if( mouseX > XminF2_3 && mouseX < XmaxF2_3 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_3, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_3, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('Watts', XminF2_3+20, Yfase+30);
  
   if( mouseX > XminF2_4 && mouseX < XmaxF2_4 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_4, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_4, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('Coulomb', XminF2_4+10, Yfase+30); 
}
function telaFase9(){
  background(2000);
  //organização das cores
  let f = color(236, 179, 255);
  let a = color(255, 249, 229);
  let u = color(0);
  image(img17,0, 230, 400, 400);
  textFont(font1);
  textSize(30);
  text('Quanto vale 7mA?', 120,50, 480);
  
   if( mouseX > XminF2_1 && mouseX < XmaxF2_1 && mouseY >Yfase5_1  && mouseY < YmaxFase5_1){ 
     noStroke();
     fill(a);
   rect(XminF2_1, Yfase5_1, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_1, Yfase5_1, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('0,07A', XminF2_1+20, Yfase5_1+30);
   
   if( mouseX > XminF2_2 && mouseX < XmaxF2_2 && mouseY > Yfase5_1 && mouseY < YmaxFase5_1){ 
    fill(a);
   rect(XminF2_2, Yfase5_1, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 21;
       tela = 22;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_2, Yfase5_1, largura2, altura2, 5);
  } 
  fill(20);
  text('0,007A', XminF2_2+15, Yfase5_1+30);
  
   if( mouseX > XminF2_3 && mouseX < XmaxF2_3 && mouseY > Yfase5_1 && mouseY < YmaxFase5_1){ 
    fill(a);
   rect(XminF2_3, Yfase5_1, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_3, Yfase5_1, largura2, altura2, 5);
  } 
  fill(20);
  text('0,0007A', XminF2_3+5, Yfase5_1+30);
  
   if( mouseX > XminF2_4 && mouseX < XmaxF2_4 && mouseY > Yfase5_1 && mouseY < YmaxFase5_1){ 
    fill(a);
   rect(XminF2_4, Yfase5_1, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_4, Yfase5_1, largura2, altura2, 5);
  } 
  fill(20);
  text('0,7A', XminF2_4+25, Yfase5_1+30); 
}
function telaFase10(){
  background(2000);
  image(img21,100,200,300,400)
  //organização das cores
  let f = color(230, 204, 255);
  let a = color(255, 249, 229);
  let u = color(0);
  textFont(font1);
  textSize(30);
  text('Qual a temperatura de 44,33°F, em Kelvin?', 15,60, 480);
  
   if( mouseX > XminF2_1 && mouseX < XmaxF2_1 && mouseY >Yfase  && mouseY < YmaxFase){ 
     noStroke();
     fill(a);
   rect(XminF2_1, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_1, Yfase, largura2, altura2, 5);
  } 
  textSize(20);
  fill(20)
  text('280° K', XminF2_1+18, Yfase+30);
   
   if( mouseX > XminF2_2 && mouseX < XmaxF2_2 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_2, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_2, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('275 K', XminF2_2+20, Yfase+30);
   if( mouseX > XminF2_3 && mouseX < XmaxF2_3 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_3, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 22;
       tela = 23;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_3, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('280 K', XminF2_3+20, Yfase+30);
  
   if( mouseX > XminF2_4 && mouseX < XmaxF2_4 && mouseY > Yfase && mouseY < YmaxFase){ 
    fill(a);
   rect(XminF2_4, Yfase, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF2_4, Yfase, largura2, altura2, 5);
  } 
  fill(20);
  text('275° K ', XminF2_4+20, Yfase+30); 
}
function telaFase11(){
  background(2000);
  //organização das cores
  let a = color(255, 249, 229);
  let f = color(242, 255, 204);
  let u = color(0);
  textFont(font1);
  textSize(30);
  text('Salvador  vai fazer  uma  viagem de São  Pulo  a  Montes  Claros, se  ele  escolher  pegar   a  BR-101  ele  percorrerá  509,524 milhas, se  ele  for pela BR-493 ele percorrerá 845,000 metros. Qual é o melhor trajeto?', 15,60, 480);
  
   if( mouseX > XminF11_1 && mouseX < XmaxF11_1 && mouseY >Yfase11  && mouseY < YmaxFase11){ 
     noStroke();
     fill(a);
   rect(XminF11_1, Yfase11, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 24;
       tela = 26;
     } 
  }else{
    fill(f);
    noStroke();
    rect(XminF11_1, Yfase11, largura2, altura2, 5);
  } 
  textSize(20);
  fill(24)
  text('BR-101', XminF11_1+15, Yfase11+30);
   
   if( mouseX > Xmin11_2 && mouseX < Xmax11_2 && mouseY > Yfase11 && mouseY < YmaxFase11){ 
    fill(a);
   rect(Xmin11_2, Yfase11, largura2, altura2, 5);
     if(mouseIsPressed){
       value = 23;
       tela = 24;
     } 
  }else{
    fill(f);
    noStroke();
    rect(Xmin11_2, Yfase11, largura2, altura2, 5);
  } 
  fill(20);
  text('BR-493', Xmin11_2+15, Yfase11+30);
}
function telaGameOver(){
  background(2000);
  image(img23, 100, 130,400,500);
   if( mouseX > 60 && mouseX < 460 && mouseY > 115 && mouseY < 160){ 
     noStroke();
     fill(230);
   rect(60, 115, 400, 45, 5);
     if(mouseIsPressed){
       value = 11;
       tela = 1;
     } 
  }else{
    fill(250);
    noStroke();
    rect(60, 115, 400, 45, 5);
  } 
  textFont(fonte6);
  textSize(40);
  fill(204,0,0)
  text('GAME OVER', 100, 150);
}
function telaVitoria(){
  background(2000);
  image(img24,100,200,300,400);
   if( mouseX > 60 && mouseX < 460 && mouseY > 115 && mouseY < 160){ 
     noStroke();
     fill(230);
   rect(60, 115, 400, 45, 5);
     if(mouseIsPressed){
       value = 11
       tela = 1;
     } 
  }else{
    fill(250);
    noStroke();
    rect(60, 115, 400, 45, 5);
  } 
  textFont(fonte6);
  textSize(40);
  fill(77, 255, 77);
  text('You win', 140, 150);
  
}
function telaInstrucoes(){
  background(fundo);
   let u = color(0);
  let j = color(230);
   if( mouseX > 20 && mouseX < 100 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(230);
   rect(20, 20, 80, 40, 5);
     if(mouseIsPressed){
       let u = color(0);
       value = 11;
       tela = 1;
     } 
  }else{
    fill(250);
    noStroke();
    rect(20, 20, 80, 40, 5);
  } 
  fill(u);
  text('Voltar', 20+10, 50);
  
textFont(fonte1);
  textSize(40);
  text('Instruções', 180,120);
  textFont(fonte2);
  textSize(25);
  text('-Descubra nossos itens - DICAS', 100, 228, 300);
  text('-Faça anotações',100, 300);
  text('-Treine seu apreendizado.', 100, 370);
  text('-Evolua nas fases.', 100, 440);
  text('-Reveja Dicas.', 100, 510);
  
}
function telaDicas(){
  background(242, 230, 255);
  
  //organização das cores
  let z = color(236, 179, 255);
  let a = color(255, 249, 229);
  let b = color(236, 229, 255);
  let c = color(255, 179, 255);
  let d = color(255, 179, 215);
  let e = color(255, 179, 217);
  let f = color(255, 179, 236);
  let g = color(255, 179, 198);
  let h = color(255, 179, 179);
  let l = color(204, 255, 242);
  let k = color(198, 179, 255);
  let u = color(0);
  
  textFont(font2);
   fill(k);
  textSize(80);
  text('Unidades', 130, 180);
  
   if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 11;
       tela = 1;
     } 
  }else{
    fill(b);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(u);
  textSize(20);
  text('Voltar', 20+25, 45)
    stroke(230);
  if( mouseX > XminBotao && mouseX < XmaxBotao && mouseY > Ymenu1 && mouseY < YmaxBotao1){
    fill(a)
    stroke(230)
    rect(Xmenu, Ymenu1, largura, altura, 15);
    if(mouseIsPressed){
      value = 2
      tela = 4
    } 
  }else{
    fill(z);
    rect(Xmenu, Ymenu1, largura, altura, 15);
    }

  textSize(40);
  fill(u);
  text('Temperatura', Xmenu + 8, 300);
  
  if( mouseX > XminBotao && mouseX < XmaxBotao && mouseY > Ymenu2 && mouseY < YmaxBotao2){ 
    fill(a);
   rect(Xmenu, Ymenu2, largura, altura, 15);
     if(mouseIsPressed){
       value = 4;
      tela = 6;
     } 
  }else{
    fill(f);
    rect(Xmenu, Ymenu2, largura, altura, 15);
  } 
  fill(u);
  text('Tempo', Xmenu + 60, 380); 
  
  if( mouseX > 260 && mouseX < 260 + largura && mouseY > Ymenu1 && mouseY < YmaxBotao1){ 
    fill(a);
   rect(260, Ymenu1, largura, altura, 15);
     if(mouseIsPressed){
       value = 3;
      tela = 5;
     } 
  }else{
    fill(c);
    rect(260, Ymenu1, largura, altura, 15);
  } 
  fill(u);
  text('Massa', 260 + 60, 300); 
  
  if( mouseX > XminBotao && mouseX < XmaxBotao && mouseY > Ymenu3 && mouseY < YmaxBotao3){ 
    fill(a);
   rect(Xmenu, Ymenu3, largura, altura, 15);
     if(mouseIsPressed){
       value = 6;
      tela = 8;
     } 
  }else{
    fill(d);
    rect(Xmenu, Ymenu3, largura, altura, 15);
  } 
  fill(u);
  text('Corrente', Xmenu + 40, 460);
  
  if( mouseX > Xmenu && mouseX < XmaxBotao && mouseY > 500 && mouseY < 500 + altura){ 
    fill(a);
   rect(Xmenu, 500, largura, altura, 15);
     if(mouseIsPressed){
       value = 8;
      tela = 10;
     } 
  }else{
    fill(h);
    rect(Xmenu, 500, largura, altura, 15);
  } 
  fill(u);
  text('Int.Luminosa', Xmenu + 15, 540);
  
  if( mouseX > 260 && mouseX < 260 + largura && mouseY > Ymenu3 && mouseY < YmaxBotao3){ 
    fill(a);
   rect(260, Ymenu3, largura, altura, 15);
     if(mouseIsPressed){
       value = 7;
      tela = 9;
     } 
  }else{
    fill(g);
    rect(260, Ymenu3, largura, altura, 15);
  } 
  fill(u);
  text('Quant. Massa', 260 + 15, 460);
  
   if( mouseX > 260 && mouseX < 260 + largura && mouseY > Ymenu2 && mouseY < YmaxBotao2){ 
    fill(a);
   rect(260, Ymenu2, largura, altura, 15);
     if(mouseIsPressed){
       value = 5;
      tela = 7;
     } 
  }else{
    fill(e);
    rect(260, Ymenu2, largura, altura, 15);
  } 
  fill(u);
  text('Comprimento', 260 + 10, 380);
}
function telaTempera(){
  background(img4);
  textFont(font2);
   if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(204, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaMassa(){
  background(img5);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(255, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaTempo(){
  background(img6);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(204, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaComp(){
  background(img7);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(255, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaCorrente(){
  background(img8);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(204, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaQM(){
  background(img9);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 20 && mouseY < 60){ 
     noStroke();
     fill(250);
   rect(20, 20, 100, 40, 5);
     if(mouseIsPressed){
       value = 0
       tela = 3;
     } 
  }else{
    fill(255, 153, 255);
    noStroke();
    rect(20, 20, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 45);
}
function telaIntL(){
  background(img10);
  textFont(font2);
  if( mouseX > 20 && mouseX < 120 && mouseY > 540 && mouseY < 580){ 
     noStroke();
     fill(250);
   rect(20, 540, 100, 40, 5);
     if(mouseIsPressed){
       value = 0;
       tela = 3;
     } 
  }else{
    fill(255, 255, 153);
    noStroke();
    rect(20, 540, 100, 40, 5);
  } 
  fill(0);
  textSize(20);
  text('Voltar', 20+25, 570);
}
function telaCreditos(){
  background(500);
  
  //Organização das cores
  let u = color(0);
  let b = color(230);
  let c = color(245);
  let f = color(255, 200, 192);
  let h = color(255, 204, 153);
  let g = color(255, 153, 153);
  
  noStroke();
  if( mouseX > 20 && mouseX < 75 && mouseY > 20 && mouseY < 70){ 
    fill(b);
   rect(20, 20, 55, 50, 5);
     if(mouseIsPressed){
       value = 11;
      tela = 1;
     } 
  }else{
    fill(c);
    rect(20, 20, 55, 50, 5);
  } 
  fill(u);
  text('Voltar', 20+10, 50);
  
  textFont(font2);
  textSize(60);
  fill(f);
  text('CRÉDITOS', 150, 80);
  
  textFont(font1);
  textSize(20);
  fill(u);
    text('Helena Almeida da Silva', 180, 368);
    text('Heron Dominguez Torres da Silva',   180, 165);
  textSize(15);
  text('Função: Educador', 180, 183);
  text('Função: Programadora', 180, 386);
  textSize(13);
  text('Graduanda em Ciências e tecnologia Universida- de Federal do Rio Grande do Norte', 180, 406, 280);
  textSize(13);
  text('Licenciado e Bacharel em Química, com mestra- do e   doutorado em Química Analítica (Universidade de São Paulo), exerce docência na área de Quimiometria e Metrologia Química junto à Uni- versidade Federal de São Paulo. Desenvolve  pesquisas aplicadas nas áreas de Bioanalítica, Mo- nitoramento Ambiental e Microfabricação de Sistemas Analíticos.', 180, 201, 280);
  image(img1, 10, 150, 150, 155);
  image(img2, 10, 350, 150,155);
  
  noStroke();
  
  fill(h);
  ellipse(480, 600, 250, 250);

 stroke(g);
 line(280, 100, 500, 100, 80, 80);
 line(0, 560, 200, 560, 480, 130);    
}

function preload() {
  font1 = loadFont('Courgette-Regular.ttf');
  font2 = loadFont('Chewy-Regular.ttf');
  img1 = loadImage('h.jpeg');
  img2 = loadImage('What.jpeg');
  img3 = loadImage('imgS1.jpeg');
  img4 = loadImage('w1.jpeg');
  img5 = loadImage('w2.jpeg');
  img6 = loadImage('w3.jpeg');
  img7 = loadImage('w4.jpeg');
  img8 = loadImage('w5.jpeg');
  img9 = loadImage('w6.jpeg');
  img10 = loadImage('w8.jpeg');
  img11 = loadImage('imgs0.jpeg');
  img12 = loadImage('imgs4.jpeg');
  img13 = loadImage('imgs9.jpeg');
  img14 = loadImage('imgs10.jpeg');
  img15 = loadImage('imgs2.jpeg');
  img16 = loadImage('imgs13.jpeg');
  img17 = loadImage('imgs14.jpeg');
  img18 = loadImage('imgs5.jpeg');
  img19 = loadImage('imgs8.jpeg');
  img20 = loadImage('imgs15.jpeg');
  img21 = loadImage('imgs17.jpeg');
  img22 = loadImage('imgs16.jpeg');
  img23 = loadImage('game.jpeg');
  img24 = loadImage('imgs12.jpeg');
  fonte1 = loadFont('Pacifico-Regular.ttf');
  fonte2 = loadFont('DancingScript-Regular.ttf');
  fundo = loadImage('fund.instrucoes.jpeg');
  fundo1 = loadImage('fund.dicas.jpeg');
  fonte3 = loadFont('GreatVibes-Regular.ttf');
  fonte4 = loadFont('Oi-Regular.ttf');
  fonte5 = loadFont('Akronim-Regular.ttf');
  fonte6 = loadFont('RubikMonoOne-Regular.ttf')
}
function setup() {
  createCanvas(500, 600);
}
function mouseClicked() {
    if(value == 0){
      tela30();
    }
  if(value == 10){
    telaFase1();
  }
}
  
  function draw() {
     if(tela == 0 || value == 01){
    tela30();
  }
    if(tela == 1 || value == 11){
    telaMenu();
  }
    if(tela == 2 || value == 12){
    telaInstrucoes();
  }
    if(tela == 3 || value == 1){
      telaDicas();
    }
    if(tela == 4 || value == 2){
      telaTempera();
    }
     if(tela == 5 || value == 3){
      telaMassa();
    }
     if(tela == 6 || value == 4){
      telaTempo();
    }
     if(tela == 7 || value == 5){
      telaComp();
    }
     if(tela == 8 || value == 6){
      telaCorrente();
    }
     if(tela == 9 || value == 7){
      telaQM();
    }
    if(tela == 10 || value == 8){
      telaIntL();
    }
    if(tela == 11 || value == 9){
      telaFase0();
    }
    if(tela == 12 || value == 120){
      telaFase1();
    }
    if(tela == 14 || value == 13){
      telaFase2();
    }
    if(tela == 15 || value == 14){
      telaFase3();
    }
    if(tela == 16 || value == 15){
      telaFase4();
    }
    if(tela == 17 || value == 16){
      telaFase5();
    }
    if(tela == 18 || value == 17){
      telaFase6();
    }
    if(tela == 19 || value == 18){
      telaFase7();
    }
    if(tela == 20 || value == 19){
      telaFase8();
    }
    if(tela == 21 || value == 20){
      telaFase9();
    }
    if(tela == 22 || value == 21){
      telaFase10();
    }
    if(tela == 23 || value == 22){
      telaFase11();
    }
     if(tela == 24 || value == 23){
     telaGameOver();
 }
    if(tela == 26 || value == 24){
     telaVitoria();
 }
     if(tela == 25 || value == 25){
     telaCreditos();
 }
}